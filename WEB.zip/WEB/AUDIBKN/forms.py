from django import forms
from AUDIBKN.models import contact, register, buy , tarjeta

class ContactoForm(forms.ModelForm):
    class Meta:
        model = contact
        fields = ['nombre', 'telefono', 'correo', 'mensaje']
