from django.shortcuts import render
from django.http import HttpResponseRedirect
from django.views.decorators.csrf import csrf_protect
from .forms import ContactoForm
def index(request):
    return render(request, 'index.html')

def buy(request):
    return render(request, 'buy.html')

def contact(request):
    return render(request, 'contact.html')

def login(request):
    return render(request, 'login.html')

def products(request):
    return render(request, 'products.html')

def register(request):
    return render(request, 'register.html')





def formulario_contacto(request):
    if request.method == 'POST':
        form = ContactoForm(request.POST)
        if form.is_valid():
            form.save()
            # Redirigir a una página de éxito o realizar otras acciones después de guardar los datos
    else:
        form = ContactoForm()
    return render(request, 'contact.html', {'form': form})

