from django.db import models

class contact(models.Model):
    nombre = models.CharField(max_length=100)
    telefono = models.CharField(max_length=20)
    correo = models.EmailField(unique=True)
    mensaje = models.TextField()
    def __str__(self):
        return self.nombre


class register(models.Model):
    nombre = models.CharField(max_length=100)
    apellido = models.CharField(max_length=20)
    correo = models.EmailField(max_length=20)
    contraseña = models.CharField(max_length=20)
    rut = models.CharField(max_length=10)
    def __str__(self):
        return self.nombre


class buy(models.Model):
    nombre = models.CharField(max_length=100)
    data_id = models.AutoField(primary_key=True)
    valor = models.EmailField()
    def __str__(self):
        return self.nombre
class tarjeta(models.Model):
    nombre = models.CharField(max_length=30)
    apellido = models.CharField(max_length=30)
    numero_tarjeta = models.CharField(max_length=15)
    cvv= models.IntegerField()
    mm_yy=models.CharField(max_length=5)
    rut = models.CharField(max_length=10)
    def __str__(self):
        return self.nombre
